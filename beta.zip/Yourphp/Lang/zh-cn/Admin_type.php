<?php
return array(
	'add_type' => '添加子分类',
	'type_manage' => '管理子分类',
);
?>