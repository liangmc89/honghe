<?php
return array(
		'URL_MAKE_HTML'=>'是否生成静态？',
		'URL_example'=>'URL示例',
		'URL_RULE'=>'URL规则',
		'URL_SHOW'=>'内容页',
		'URL_LIST'=>'列表页',
		'URL_SHOW_VAR'=>'内容页可用变量',
		'URL_LIST_VAR'=>'列表页可用变量',
		'URL_SHOW_README'=>'栏目目录：{$catdir} , 栏目ID：{$catid} , 模型名称：{$module}  , 模型id：{$moduleid}  ，ID：{$id} <br>年：{$year} 月：{$month}，日：{$day} ， 分页：{$page}<br>生成HTML页时可用父栏目路径：{$parentdir} ',
		'URL_LIST_README'=>'栏目目录：{$catdir}  ， 栏目ID：{$catid} , 模型名称：{$module}  , 模型id：{$moduleid} <br> 分页：{$page}<br>生成HTML页时可用父栏目路径：{$parentdir}',
);
?>