<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta content="initial-scale=1.0,user-scalable=no,maximum-scale=1.0,width=device-width" name="viewport">
	<meta name="keywords" content="<?php echo ($seo_keywords); ?>" />
	<meta name="description" content="<?php echo ($seo_description); ?>" />
	<title><?php echo ($seo_title); ?>-<?php echo ($site_name); ?></title>
	<link rel="shortcut icon" type="image/ico" href="">
	<link rel="stylesheet" type="text/css" href="../Public/css/reset.css">
	<link rel="stylesheet" type="text/css" href="../Public/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../Public/css/index.css">
	<link rel="stylesheet" type="text/css" href="../Public/css/swiper.min.css">
	<script type="text/javascript" src="../Public/js/jquery-1.11.1.min.js"></script>
	<script type="text/javascript" src="../Public/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../Public/js/swiper.min.js"></script>
	<script type="text/javascript" src="../Public/js/jquery.easing.1.3.js"></script>
	<script type="text/javascript" src="../Public/js/case.js"></script>
	<script type="text/javascript" src="../Public/js/index.js"></script>
</head>
<body>

<!-- header -->
<div class="header <?php if($ishome) : ?>header1<?php else :?>header2<?php endif;?>">
	<div class="container-fluid">
		<div class="w1200">
			<a href="<?php echo ($site_url); ?>" class="company-logo"><img src="<?php echo ($logo); ?>"></a>
			<ul class="nav">
				<?php $i=0;foreach($Categorys as $key=>$r):if( $r['ismenu']==1 && intval(0)==$r["parentid"] ) :++$i;?><li class="<?php if($r[id]==$bcid || ($bcid == 0 && $r[id]==$T[m_home_catid])) : ?>on<?php endif;?>">
					<a href="<?php if($r[id]==$T[m_zhineng_catid] || $r[id]==$T[m_fangan_catid]) : ?>javascript:void(0)<?php else : echo ($r["url"]); endif;?>"><?php echo ($r["catname"]); ?></a>
					<?php if($r[id]==$T[m_zhineng_catid] || $r[id]==$T[m_fangan_catid] || $r[id]==$T[m_about_catid]) : ?>
						<div class="down-nav">
							<div class="w1200">
								<div class="down-item <?php if($r[id]==$T[m_zhineng_catid]) : ?>down-item1<?php endif; if($r[id]==$T[m_fangan_catid]) : ?>down-item2<?php endif; if($r[id]==$T[m_about_catid]) : ?>down-item3<?php endif;?>">

									<?php if($r[id]==$T[m_zhineng_catid]) : ?>
										<ul class="clearfix">
											<?php $i=0;foreach($Categorys as $key=>$rd):if( $rd['ismenu']==1 && intval($r[id])==$rd["parentid"] ) :++$i;?><li>
													<h4><?php echo ($rd["catname"]); ?></h4>
													<?php  $_result=M("Product")->field("*")->where(" 1  and lang=1 AND status=1  AND catid in(21,22,23,24)")->order("id asc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$k):++$i;$mod = ($i % 2 );?><a href="<?php echo ($k["url"]); ?>"><?php echo ($k["title"]); ?></a><?php endforeach; endif;?>
												</li><?php endif; endforeach;?>
										</ul>
									<?php endif;?>

								<?php if($r[id]==$T[m_fangan_catid]) : ?>
									<?php  $_result=M("Picture")->field("*")->where(" 1  and lang=1 AND status=1  AND catid=14")->order("id asc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$k):++$i;$mod = ($i % 2 );?><a href="<?php echo ($k["url"]); ?>">
												<img src="../Public/images/icon_01.png">
												<P><?php echo ($k["title"]); ?></P>
											</a><?php endforeach; endif;?>
								<?php endif;?>

								<?php if($r[id]==$T[m_about_catid]) : ?>
									<ul class="clearfix">
										<?php $i=0;foreach($Categorys as $key=>$rd):if( $rd['ismenu']==1 && intval($r[id])==$rd["parentid"] ) :++$i;?><li>
											<h4><?php echo ($rd["catname"]); ?></h4>
											<?php $i=0;foreach($Categorys as $key=>$rdd):if( $rdd['ismenu']==1 && intval($rd[id])==$rdd["parentid"] ) :++$i;?><a href="<?php echo ($rdd["url"]); ?>"><?php echo ($rdd["catname"]); ?></a><?php endif; endforeach;?>
										</li><?php endif; endforeach;?>
									</ul>
					            <?php endif;?>

								</div>
							</div>
						</div>
					<?php endif;?>

				</li><?php endif; endforeach;?>
			</ul>
		</div>
	</div>
</div>
<!-- tel header -->
<div class="tel-header clearfix">
	<a href="<?php echo ($site_url); ?>"><img src="<?php echo ($logo); ?>"></a>
	<span class="menu"></span>
</div>
<!-- tel nav -->
<div class="tel-nav" id="tel-nav">
	<ul>
		<li class="<?php if($bcid==$T[m_home_catid]) : ?>on<?php endif;?>"><a href="/">企业首页</a></li>
		<li class="<?php if($bcid==$T[m_news_catid]) : ?>on<?php endif;?>"><a href="<?php echo ($Categorys[$T[m_news_catid]][url]); ?>"><?php echo ($Categorys[$T[m_news_catid]][catname]); ?></a></li>
		<li class="<?php if($bcid==$T[m_anli_catid]) : ?>on<?php endif;?>"><a href="<?php echo ($Categorys[$T[m_anli_catid]][url]); ?>"><?php echo ($Categorys[$T[m_anli_catid]][catname]); ?></a></li>
		<li class="<?php if($bcid==$T[m_ruodian_catid]) : ?>on<?php endif;?>">
			<a href="javascript:void(0);"><?php echo ($Categorys[$T[m_ruodian_catid]][catname]); ?><em></em></a>
			<div class="tel-down-nav">
				<?php  $_result=M("Product")->field("*")->where(" 1  and lang=1 AND status=1  AND catid=22")->order("id asc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$k):++$i;$mod = ($i % 2 );?><a href="<?php echo ($k["url"]); ?>" class="<?php if($catid==$k[id]) : ?>on<?php endif;?>"><?php echo ($k["title"]); ?></a><?php endforeach; endif;?>
			</div>
		</li>
		<li class="<?php if($bcid==$T[m_jifang_catid]) : ?>on<?php endif;?>">
			<a href="javascript:void(0);"><?php echo ($Categorys[$T[m_jifang_catid]][catname]); ?><em></em></a>
			<div class="tel-down-nav">
				<?php  $_result=M("Product")->field("*")->where(" 1  and lang=1 AND status=1  AND catid=23")->order("id asc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$k):++$i;$mod = ($i % 2 );?><a href="<?php echo ($k["url"]); ?>" class="<?php if($catid==$k[id]) : ?>on<?php endif;?>"><?php echo ($k["title"]); ?></a><?php endforeach; endif;?>
			</div>
		</li>
		<li>
			<a href="javascript:void(0);"><?php echo ($Categorys[$T[m_anfang_catid]][catname]); ?><em></em></a>
			<div class="tel-down-nav">
				<?php  $_result=M("Product")->field("*")->where(" 1  and lang=1 AND status=1  AND catid=24")->order("id asc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$k):++$i;$mod = ($i % 2 );?><a href="<?php echo ($k["url"]); ?>" class="<?php if($catid==$k[id]) : ?>on<?php endif;?>"><?php echo ($k["title"]); ?></a><?php endforeach; endif;?>
			</div>
		</li>
		<li>
			<a href="javascript:void(0);"><?php echo ($Categorys[$T[m_anli_catid]][catname]); ?><em></em></a>
			<div class="tel-down-nav">
				<?php  $_result=M("Anli")->field("*")->where(" 1  and lang=1 AND status=1  AND catid in(27,44,45,46,47,48,49,50)")->order("id asc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$k):++$i;$mod = ($i % 2 );?><a href="<?php echo ($k["url"]); ?>" class="<?php if($catid==$k[id]) : ?>on<?php endif;?>"><?php echo ($k["title"]); ?></a><?php endforeach; endif;?>
			</div>
		</li>
		<li>
			<a href="javascript:void(0);"><?php echo ($Categorys[$T[m_liaojie_catid]][catname]); ?><em></em></a>
			<div class="tel-down-nav">
				<?php $i=0;foreach($Categorys as $key=>$k):if( $k['ismenu']==1 && intval(11)==$k["parentid"] ) :++$i;?><a href="<?php echo ($k["url"]); ?>" class="<?php if($catid==$k[id]) : ?>on<?php endif;?>"><?php echo ($k["catname"]); ?></a><?php endif; endforeach;?>
			</div>
		</li>
		<li>
			<a href="javascript:void(0);"><?php echo ($Categorys[$T[m_zhichi_catid]][catname]); ?><em></em></a>
			<div class="tel-down-nav">
				<?php $i=0;foreach($Categorys as $key=>$k):if( $k['ismenu']==1 && intval(12)==$k["parentid"] ) :++$i;?><a href="<?php echo ($k["url"]); ?>" class="<?php if($catid==$k[id]) : ?>on<?php endif;?>"><?php echo ($k["catname"]); ?></a><?php endif; endforeach;?>
			</div>
		</li>
		<li>
			<a href="javascript:void(0);"><?php echo ($Categorys[$T[m_peixun_catid]][catname]); ?><em></em></a>
			<div class="tel-down-nav">
				<?php $i=0;foreach($Categorys as $key=>$k):if( $k['ismenu']==1 && intval(25)==$k["parentid"] ) :++$i;?><a href="<?php echo ($k["url"]); ?>" class="<?php if($catid==$k[id]) : ?>on<?php endif;?>"><?php echo ($k["catname"]); ?></a><?php endif; endforeach;?>
			</div>
		</li>
		<li>
			<a href="javascript:void(0);"><?php echo ($Categorys[$T[m_shengming_catid]][catname]); ?><em></em></a>
			<div class="tel-down-nav">
				<?php $i=0;foreach($Categorys as $key=>$k):if( $k['ismenu']==1 && intval(26)==$k["parentid"] ) :++$i;?><a href="<?php echo ($k["url"]); ?>" class="<?php if($catid==$k[id]) : ?>on<?php endif;?>"><?php echo ($k["catname"]); ?></a><?php endif; endforeach;?>
			</div>
		</li>

	</ul>
</div>
<script type="text/javascript">
	jQuery(function(){
		jQuery(".header1").hover(function(){
			jQuery(this).addClass("header_hover");
			jQuery(this).find(".company-logo img").attr("src","../Public/images/company-logo.png");
		},function(){
			jQuery(this).removeClass("header_hover");
			jQuery(this).find(".company-logo img").attr("src","../Public/images/company-logo2.png");
		});
		jQuery(window).scroll(function(){
			jQuery(".header1").addClass("header_hover");
			jQuery(".company-logo img").attr("src","../Public/images/company-logo.png");
			var scrollY=jQuery(document).scrollTop();
			if(scrollY<=0){
				jQuery(".header1").removeClass('header_hover');
				jQuery(".company-logo img").attr("src","../Public/images/company-logo2.png");
			}
		});

	});
</script>
<!-- header  end-->












		<!-- web-nav -->
<div class="web-nav-box">
	<div class="w1200">
		<div  class="web-nav">
			<a href="/">宏和首页&gt;</a>
			<a href="<?php echo ($Categorys[$bcid][url]); ?>"><?php echo ($Categorys[$bcid][catname]); ?></a>
		</div>
	</div>
</div>
<!-- banner -->
<div class="banner">
	<img src="<?php echo ($Categorys[$bcid][image]); ?>">
</div>
<!-- main-top -->
<div class="main-top">
	<div class="container">
		<?php $i=0;foreach($Categorys as $key=>$r):if( $r['ismenu']==1 && intval($bcid)==$r["parentid"] ) :++$i;?><a href="<?php echo ($r["url"]); ?>" class="<?php if($r[id]==$catid) : ?>on<?php endif;?>"><?php echo ($r["catname"]); ?></a><?php endif; endforeach;?>
	</div>
</div>
<div class="main">
	<div class="container">
		<ul class="row case-list">
			<?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$r): $mod = ($i % 2 );++$i;?><li class="col-md-4 col-sm-6 col-xs-12">
					<a href="<?php echo ($r["url"]); ?>">
						<img src="<?php echo ($r["thumb"]); ?>">
						<p><?php echo (strip_cut($r["title"],30)); ?></p>
					</a>
				</li><?php endforeach; endif; else: echo "" ;endif; ?>
		</ul>
		<div class="page">
			<?php echo ($pages); ?>
			<!--<a href="" class="on">1</a>-->
			<!--<a href="">2</a>-->
			<!--<a href="">3</a>-->
			<!--<a href="">4</a>-->
			<!--<a href="">5</a>-->
			<!--<a href="">6</a>-->
			<!--<a href="">7</a>-->
			<!--<a href="">8</a>-->
			<!--<a href="">9</a>-->
			<!--<span>...</span>-->
			<!--<a href="">下一页</a>-->
			<!--<a href="">尾页</a>-->
		</div>
	</div>
</div>






 


<!-- id-item7 -->
<div class="id-item id-item7">
    <div class="container">
        <div class="id-title">
            <p>PARTNER</p>
            <h2>合作机构</h2>
            <img src="../Public/images/partner-icon.png">
        </div>
        <div class="small-pic-box">
            <div class="small-pic">
                <ul class="small-pic-list clearfix">
                    <?php  $_result=M("Hezuo")->field("*")->where(" 1  and lang=1 AND status=1  AND catid=51")->order("id asc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$r):++$i;$mod = ($i % 2 );?><li><img src="<?php echo ($r["thumb"]); ?>"></li><?php endforeach; endif;?>
                </ul>
            </div>
            <span class="pleft">&lt;</span>
            <span class="pright">&gt;</span>
        </div>
    </div>
</div>
<!-- 友情链接 -->
<div class="id-item friend-link">
    <div class="container">
        <div class="friend-link-title"><span class="id-h3">[友情链接/LINK]</span></div>
        <div>
            <?php  $_result=M("Link")->field("*")->where(" status = 1  and lang=1 and typeid=1 and  linktype=1")->order("id asc")->limit("10")->select();; if ($_result): $i=0;foreach($_result as $key=>$r):++$i;$mod = ($i % 2 );?><a href="<?php echo ($r['siteurl']); ?>" target="_blank"><?php echo ($r["name"]); ?></a><?php endforeach; endif;?>
        </div>
    </div>
</div>
<!-- 友情链接 -->
<!-- footer --

<!-- footer -->
<div class="footer">
    <div class="container">
        <div class="footer-mian">
            <form action="<?php echo URL('User-Post/insert2');?>" method="post" class="footer-form clearfix">
                <input type="hidden"  name="catid" value="<?php echo ($catid); ?>" />
                <input type="hidden"  name="moduleid" value="8" />
                <input type="hidden"  name="lang" value="1" />
                <div class="code">
                    <img src="/Uploads/201707/59783f413caa5.png" alt="" />
                    <p>关注宏和科技公众号</p>
                </div>
                <h3>在  线  留  言</h3>
                <div class="form-box">
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="text" name="username" class="name" placeholder="您的尊称 Name">
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="email" name="email" class="email" placeholder="您的邮箱 Emall">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="tel" name="telephone" class="tel" placeholder="您的电话 Phone">
                        </div>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="text" name="address" class="address" placeholder="您的地址 Address">
                        </div>
                    </div>
                    <textarea placeholder="备注……" name="content"></textarea>
                </div>
                <input type="submit" name="" value="提交">
            </form>
            <div class="footer-info">广州宏和网络科技有限公司&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;粤ICP备11033407号-1 &nbsp;&nbsp;&nbsp;&nbsp;地址：广州市科学城科学大道162号创意大厦B1栋405室&nbsp;&nbsp;总部电话：020-28068111&nbsp;&nbsp;全国免费服务热线：400-668-1878      传真：020-32211853</div>

        </div>
    </div>
</div>
<!-- footer fixed-->
<div class="lfooter">
    <ul>
        <li><a href="/"><img src="../Public/images/dbsy.png" ><br>
            网站首页</a></li>
        <li><a href="tel:<?php echo ($phone); ?>"><img src="../Public/images/dbdh.png"><br>
            电话咨询</a></li>
        <li><a href="http://wpa.qq.com/msgrd?v=3&amp;uin=<?php echo ($qq); ?>&amp;site=qq&amp;menu=yes" target="_blank"><img src="../Public/images/dbqq.png" ><br>
            QQ咨询</a></li>
        <li><a href="<?php echo ($Categorys[$T[m_contact_catid]][url]); ?>"><img src="../Public/images/dblx.png"><br>
            <?php echo ($Categorys[$T[m_contact_catid]][catname]); ?></a></li>
    </ul>
</div>
</body>
</html>